import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from  './home/home.component';
import { AboutComponent } from  './about/about.component';
import { ContactComponent } from  './contact/contact.component';
import { ResumeComponent } from './resume/resume.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { ServicesComponent } from './services/services.component';
import {PorfolioDetailComponent} from './portfolio/porfolio-detail/porfolio-detail.component';


const  routes: Routes  = [
  {
  path:  'home',
  component:  HomeComponent
  },
  {
  path:  'about',
  component:  AboutComponent
  },
  {
  path:  'contact',
  component:  ContactComponent
  },
  {
    path:  'resume',
    component:  ResumeComponent
    },
  {
    path:  'portfolio',
    component:  PortfolioComponent
  },
  {
    path:  'services',
    component:  ServicesComponent
  },
  {
    path:  'portfolioDetail',
    component:  PorfolioDetailComponent
  },
    { path: '', pathMatch: 'full', redirectTo: 'home'},
  
  { path: '**', pathMatch: 'full', redirectTo: 'home'}


];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
