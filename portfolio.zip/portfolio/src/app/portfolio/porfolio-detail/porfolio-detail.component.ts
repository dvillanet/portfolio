import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-porfolio-detail',
  templateUrl: './porfolio-detail.component.html',
  styleUrls: ['./porfolio-detail.component.css']
})
export class PorfolioDetailComponent {

  @Output() noHeader: EventEmitter<boolean>;

  constructor() {
    this.noHeader = new EventEmitter();
    this.noHeader.emit(true);
  }

}
