import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PorfolioDetailComponent } from './porfolio-detail.component';

describe('PorfolioDetailComponent', () => {
  let component: PorfolioDetailComponent;
  let fixture: ComponentFixture<PorfolioDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PorfolioDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PorfolioDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
