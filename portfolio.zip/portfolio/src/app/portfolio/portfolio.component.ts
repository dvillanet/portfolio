import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css']
})
export class PortfolioComponent implements OnInit {


  constructor() {

  }

  
  ngOnInit(): void {
   
   // recargar la página una vez
    if (window.location.href.indexOf('reload') == -1) {
      window.location.replace(window.location.href+'?reload');
 }
  }

}

