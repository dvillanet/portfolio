import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-update',
  templateUrl: './project-update.component.html',
  styleUrls: ['./project-update.component.css']
})
export class ProjectUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
